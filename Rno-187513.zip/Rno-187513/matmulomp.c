#include<stdio.h>
#include<stdlib.h>
#include<omp.h>

#define MAX 4
#define MAX_THREAD 4

int matrixA[MAX][MAX];
int matrixB[MAX][MAX];
int matrixC[MAX][MAX];

void main()
{

int j=0,m,n;
int k=0;

for(j=0;j<MAX;j++)
	for(k=0;k<MAX;k++)
	{	
		matrixA[j][k]= rand() % 10;
		matrixB[j][k]= rand() % 10;
	}

printf("Matrix A\n");
for(m=0;m<MAX;m++)
{
	for(n=0;n<MAX;n++)
	{
		printf("%d\t", matrixA[m][n]);
	}
	printf("\n");
}
printf("\n");

printf("Matrix B\n");
for(m=0;m<MAX;m++)
{
	for(n=0;n<MAX;n++)
	{
		printf("%d\t", matrixB[m][n]);
	}
	printf("\n");
}
printf("\n");

#pragma omp parallel for num_threads(MAX_THREAD)		
for(int i = 0; i < MAX; i++)  
	for(int j = 0; j < MAX; j++)  
        	for(int k = 0; k < MAX; k++)  
                	matrixC[i][j] += matrixA[i][k] * matrixB[k][j]; 


printf("Resultant Matrix\n");
for(m=0;m<MAX;m++)
{
	for(n=0;n<MAX;n++)
	{
		printf("%d\t", matrixC[m][n]);
	}
	printf("\n");
}


}
    
  


