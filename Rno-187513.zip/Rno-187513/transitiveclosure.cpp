
#include<stdio.h> 
#include<omp.h>

// Number of vertices in the graph 
#define V 4 


void printSolution(int reach[][V]); 

// Prints transitive closure of graph[][] using Floyd Warshall algorithm 
void transitiveClosure(int graph[][V]) 
{ 
	
	int reach[V][V], i, j, k; 

	for (i = 0; i < V; i++) 
		for (j = 0; j < V; j++) 
			reach[i][j] = graph[i][j]; 

	#pragma omp parallel for 
	for (k = 0; k < V; k++) 
	{ 
		// Pick all vertices as source one by one 
		for (i = 0; i < V; i++) 
		{ 
			// Pick all vertices as destination for the above picked source 
			for (j = 0; j < V; j++) 
			{	
				#pragma omp critical 
				reach[i][j] = reach[i][j] || (reach[i][k] && reach[k][j]); 
			} 
		} 
	} 

	// Print the shortest distance matrix 
	printSolution(reach); 
} 


void printSolution(int reach[][V]) 
{ 
	printf ("Following matrix is transitive closure of the given graph\n"); 
	for (int i = 0; i < V; i++) 
	{ 
		for (int j = 0; j < V; j++) 
			printf ("%d ", reach[i][j]); 
		printf("\n"); 
	} 
} 


int main() 
{ 
	
	int graph[V][V] = { {1, 1, 0, 1}, 
				{0, 1, 1, 0}, 
				{0, 0, 1, 1}, 
				{0, 0, 0, 1} 
					}; 

	// Print the solution 
	transitiveClosure(graph); 
	return 0; 
} 

