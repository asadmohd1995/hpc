#include<omp.h>
#include <iostream> 
#include <algorithm> 
#include <vector>
using namespace std; 
#define MAX_THREAD 4
#define RANGE 100
#define MAX 10 
int arr[MAX];
  
vector<float> b[MAX_THREAD]; 


void bucketSort() 
{
int index=RANGE/MAX_THREAD;

for(int i=0;i<MAX;i++)
{
	if(arr[i]<index)
		b[0].push_back(arr[i]);

	else if(arr[i]>=index+1 && arr[i]<2*index)
		b[1].push_back(arr[i]);

	else if(arr[i]>=(2*index+1) && arr[i]<3*index)
		b[2].push_back(arr[i]);
	
	else if(arr[i]>=(3*index+1) && arr[i]<4*index)
		b[3].push_back(arr[i]);	 
	 

}

#pragma omp parallel for num_threads(MAX_THREAD)
for(int i=0; i < MAX_THREAD; i++)
	sort(b[i].begin(), b[i].end()); 
 

    
int in = 0; 
for (int i = 0; i < MAX_THREAD; i++) 
	for (int j = 0; j < b[i].size(); j++) 
          	arr[in++] = b[i][j]; 
} 
  

int main() 
{ 
for(int i=0;i<MAX;i++)
	arr[i]=rand()%RANGE;
   
for(int i=0; i<MAX; i++) 
	cout << arr[i] << " ";
        cout<<endl; 

bucketSort();
    
cout << "Sorted array is \n"; 
for(int i=0; i<MAX; i++) 
       cout << arr[i] << " ";
       cout<<endl; 
return 0; 
} 
