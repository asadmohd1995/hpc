#include<stdio.h>
#include<omp.h>
#include<stdlib.h>

#define size 16
int array[size];

void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

int partition (int l, int r, int pivot)
{
	int i;
	int pivotValue = array[pivot];
	swap(&array[pivot],&array[r]);

	int idx = l;
	for(i=l; i<r; i++)
	{
		if(array[i] <= pivotValue)
		{
			swap(&array[i],&array[idx]);
			idx++;
		}
	}

	swap(&array[idx],&array[r]);
	return idx;
}
void parallel_quicksort(int l, int r)
{
	if(l < r)
	{
		int pivotIndex = l + (r-l)/2 ;
		pivotIndex = partition(l,r,pivotIndex);

		#pragma omp task
		parallel_quicksort(l,pivotIndex-1);

		#pragma omp task
		parallel_quicksort(pivotIndex+1,r);
		
	}
}

int main()
{
	int i=0;

	for(i=0; i<size; i++)
		array[i] = rand()%10000;

	printf("Before Sorting:\n ");
	for(i=0; i<size; i++)
		printf("%d ",array[i]);

	#pragma omp parallel_quicksort
	{
		#pragma omp single
		parallel_quicksort(0,size-1);
	}
	

	printf("\nSorted Array:\n");
	for(i=0; i<size; i++)
		printf("%d ",array[i]);

	return 0;
}
