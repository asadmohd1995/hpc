#include<stdio.h>
#include<omp.h>
#include<stdlib.h>

#define NODES 8
#define INT_MAX 1000000

int graph[NODES][NODES];
bool sptSet[NODES];
int distance[NODES];

//minimum distance calculation
int minDistance(int distance[], bool sptSet[]) 
{ 
 
   int min = INT_MAX, min_index; 
   
   #pragma omp parallel for 
   for (int v = 0; v < NODES; v++) 
   {
   	 #pragma omp critical	
     if (sptSet[v] == false && distance[v] <= min) 
         min = distance[v], min_index = v; 
   }
   
   return min_index; 
} 
   
void dijkstra() 
{ 
    #pragma omp parallel for
    for (int i = 0; i < NODES; i++) 
        distance[i] = INT_MAX, sptSet[i] = false; 
   
    
     distance[0] = 0; 
   
    
     for (int count = 0; count < NODES-1; count++) 
     { 
       
       int u = minDistance(dist, sptSet); 
   
       
       sptSet[u] = true; 

       #pragma omp parallel for
       for (int v = 0; v < NODES; v++) 
  		{
  			if (!sptSet[v] && graph[u][v] && distance[u] != INT_MAX  
                                       && distance[u]+graph[u][v] < distance[v]) 
            distance[v] = distance[u] + graph[u][v]; 
  		} 
          
         
     } 
} 

int main()
{
	
	printf("Graph\n");
	//Initialization
	for(int i=0; i<NODES; i++)
	{
		for(int j=0; j<NODES; j++)
		{
			if(i==j)
				graph[i][j] = 0;

			else if(i < j)
			{
				int temp = rand()%100;
				graph[i][j] = temp;
				graph[j][i] = temp;
			}


			printf("%d ",graph[i][j]);
		}

		printf("\n");
	}

	dijkstra();
	
	printf("Distance:\n");
	for (int i = 0; i < NODES; i++) 
	    printf("%d : %d\n", i, distance[i]);
	
}
