#include<stdio.h>
#include<omp.h>
#include<stdlib.h>

#define SIZE 32

int arr[SIZE];

void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

void compareAndswap(int i, int j, int dir) 
{ 
    if (dir==(arr[i]>arr[j])) 
        swap(&arr[i],&arr[j]); 
} 
  
void bitonicMerge(int low, int count, int dir) 
{ 
    if (count>1) 
    { 
        int k = count/2;
        #pragma omp parallel
        {
            #pragma omp for
            for (int i=low; i<low+k; i++) 
                compareAndswap(i, i+k, dir);


            #pragma omp sections
            {
                #pragma omp section
                {
                bitonicMerge(low, k, dir); 
                }

                #pragma omp section
                {
                bitonicMerge(low+k, k, dir); 
                } 
            }

        }   
    } 
} 
  
void bitonicSort(int low, int count, int dir) 
{ 
    if (count>1) 
    { 
        int k = count/2; 
  
        #pragma omp parallel sections
        {
            #pragma omp section
            {
                // sort in ascending order 
                bitonicSort(low, k, 1); 
            }

            #pragma omp section
            {
                // sort in descending order 
                bitonicSort(low+k, k, 0); 
            } 
        }
        
  
        
  
        // Will merge whole sequence in ascending order  
        bitonicMerge(low, count, dir); 
    } 
} 
    
int main() 
{ 
    for(int i=0; i<SIZE; i++)
		arr[i] = rand()%100;
    
    printf("Before Sorting:\n");
    for(int i=0; i<SIZE; i++)
	printf("%d ",arr[i]);
  
    //dir = 1 Ascending
    //dir = 0 descending 
    bitonicSort(0, SIZE, 1); 
  
    printf("\nSorted array: \n"); 
    for (int i=0; i<SIZE; i++) 
        printf("%d ", arr[i]); 
    return 0; 
} 
