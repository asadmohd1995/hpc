#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX 10

int main()
{
    int i,j,t;
    int arr[MAX];

    for(i=0;i<MAX;i++)
    {
        arr[i] = rand()%100;
    }
   
    printf("Array Elements Before Sorting: \n");
   
    for(i=0;i<MAX;i++)
    printf("%d ",arr[i]);

    double start_time;
    start_time = omp_get_wtime();

   
    for(i=0;i<MAX;i++)
    {   
        if(i%2==0)
        {
            #pragma omp parallel for private(t,j) shared(a)
            for(j=0;j<MAX-1;j+=2)
            {
                if(arr[j]> arr[j+1])
                {
                    t = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = t;
                }
            }
        }
        else
        {
            #pragma omp parallel for private(t,j) shared(a)
            for(j=1;j<MAX-1;j+=2)
            {
                if(arr[j]> arr[j+1])
                {
                    t = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = t;
                }
            }
        }
       
    }

    printf("\nExecution time = %lf seconds :", omp_get_wtime() - start_time);

    printf("\nSorted Array: \n");
    for(i=0;i<MAX;i++)
    printf("%d ",arr[i]);
    printf("\n");
}
