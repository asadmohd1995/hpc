#include<stdio.h>
#include<omp.h>
#include<stdlib.h>

#define NODES 4
#define THREADS 2
#define INT_MAX 999999

int g[NODES][NODES];
bool mstSet[NODES];
int key[NODES];
int updateNode;
int sum=0;

int minKey(int key[], bool mstSet[]) 
{ 

int min = INT_MAX, min_index; 

#pragma omp parallel for  
for (int v = 0; v < NODES; v++)
{
	#pragma omp critical
	if (mstSet[v] == false && key[v] < min) 
        min = key[v], min_index = v;
} 
     
  
return min_index; 
} 
 
void primMST() 
{ 
    
    #pragma omp parallel for 
    for (int i = 0; i < NODES; i++) 
        key[i] = INT_MAX, mstSet[i] = false; 
  
    
    key[0] = 0;         
  
    for (int count = 0; count < NODES; count++) 
    { 
        int u = minKey(key, mstSet); 
 		sum += key[u];
        mstSet[u] = true; 
  
  	#pragma omp parallel for
        for (int v = 0; v < NODES; v++) 
 		{
 			if (g[u][v] && mstSet[v] == false && g[u][v] < key[v]) 
             	key[v] = g[u][v];
 		} 
   
         
    } 
} 

int main()
{
	
	printf("Graph:\n");
	//Initialization
	for(int i=0; i<NODES; i++)
	{
		for(int j=0; j<NODES; j++)
		{
			if(i==j)
				g[i][j] = 0;

			else if(i < j)
			{
				int temp = rand()%100;
				g[i][j] = temp;
				g[j][i] = temp;
			}


			printf("%d ",g[i][j]);
		}

		printf("\n");
	}

	primMST();
	printf("MST-%d\n",sum);
}
