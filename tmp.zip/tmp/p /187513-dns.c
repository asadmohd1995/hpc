#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define SIZE 15
#define BLK 5

pthread_mutex_t mut[SIZE/BLK][SIZE/BLK];

int a[SIZE][SIZE], b[SIZE][SIZE], c[SIZE][SIZE] = {0};

/*----------------------------------------------------------*/

void fill(int m[SIZE][SIZE])
{
	int i, j, n = 0;

	for (i=0; i<SIZE; i++)
		for (j=0; j<SIZE; j++)
			m[i][j] = rand()%17;
}

/*----------------------------------------------------------*/

void mult(int x, int y, int z)
{	int tmp;
	for(int i=x*BLK; i<(x+1)*BLK; i++)
		for(int j=y*BLK; j<(y+1)*BLK; j++)
			for(int k=z*BLK; k<(z+1)*BLK; k++)
			{
				tmp = a[i][k] * b[k][j];
				pthread_mutex_lock(&mut[i][j]);
				c[i][j] += tmp;
				pthread_mutex_unlock(&mut[i][j]);
			}
		
}

/*----------------------------------------------------------*/

void *th_fun(void *s)
{
	int x = (*((int *) s))/(SIZE/BLK);

	int y = x%(SIZE/BLK);
	x = x/(SIZE/BLK);
	int z = (*((int *) s))%(SIZE/BLK);
	//	printf("x: %d\ty: %d\tz: %d\n", x, y ,z);
		mult(x, y, z);
	
	pthread_exit(NULL);
}

/*----------------------------------------------------------*/

int main()
{
	
	fill(a);
	fill(b);
	
	pthread_t threads[SIZE*SIZE*SIZE];
	int th_args[SIZE*SIZE*SIZE];

	for(int i=0; i<SIZE/BLK; i++)
		for(int j=0; j<SIZE/BLK; j++)
			pthread_mutex_init(&mut[i][j], NULL);

	
	
	for(int i=0; i<(SIZE/BLK)*(SIZE/BLK)*(SIZE/BLK); i++)
	{	
		th_args[i] = i;
		pthread_create(&threads[i], NULL, th_fun, &th_args[i]);
	}

	
	for(int i=0; i<(SIZE/BLK)*(SIZE/BLK)*(SIZE/BLK); i++)
	{	
		pthread_join(threads[i], NULL);
	}
	
	printf("\n\t MATRIX \"A\"\n");	
	
	for(int i=0; i<SIZE; i++)
	{
		for(int j=0; j<SIZE; j++)
			printf("%3d ", a[i][j]);
		printf("\n");
	}
	
	printf("\n\t MATRIX \"B\"\n");
	
	for(int i=0; i<SIZE; i++)
	{
		for(int j=0; j<SIZE; j++)
		{
			printf("%3d ", b[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\tMATRIX \"C\" = \"A\" * \"B\"\n");
		
	for(int i=0; i<SIZE; i++)
	{
		for(int j=0; j<SIZE; j++)
		{
			printf("%3d ", c[i][j]);
		}
		printf("\n");
	}
	
	
	return 0;	
}
