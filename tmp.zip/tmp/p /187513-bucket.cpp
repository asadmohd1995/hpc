#include <iostream> 
#include <algorithm> 
#include <vector> 
#include<stdio.h>
using namespace std; 
#define MAX 10000
#define BUCKET 20
#define MAX_THREAD 20
#define ELEMENTS 1000
//int n = sizeof(arr)/sizeof(arr[0]);

int arr[MAX];
//pthread_barrier_t barrier;

  

void create(){

  for (int i = 0; i <MAX; ++i)
  {
    arr[i]=rand()%ELEMENTS;
  }
}

int select(int a)
{
  int buck,ind,index;
  ind=ELEMENTS/BUCKET;
  index=a/ind;
  return index;
}

void * bucketSort(void *arg) 
{ 
    int n = sizeof(arr)/sizeof(arr[0]);
    vector<int> b[n]; 
     
    for (int i=0; i<n; i++) 
    {   
       int bi= select(arr[i]);
       //cout << bi;
       
       b[bi].push_back(arr[i]); 
       
    } 
    cout << endl;
    /*
    for (int i = 0; i < n; ++i)
    {
      int size1=b[i].size();
      for (int j = 0; j <size1; ++j)
      {
        printf("%d  ", b[i][j]);
      }
      printf("\n");
    }*/


    for (int i=0; i<n; i++) 
       sort(b[i].begin(), b[i].end()); 
  
    int index = 0; 
    for (int i = 0; i < n; i++) 
        for (int j = 0; j < b[i].size(); j++) 
          arr[index++] = b[i][j]; 
} 
  
/* Driver program to test above funtion */
int main() 
{ 
    create();
     int t = sizeof(arr)/sizeof(arr[0]);
    //pthread_barrier_init(&barrier,NULL,MAX_THREAD);
    cout << "Array is" << endl;
    for (int i=0; i<MAX; i++) 
       cout << arr[i] << " "; 
    cout << endl;

     
    //bucketSort(arr, n); 


    int tid[2]={0,1};

    pthread_t thread[MAX_THREAD];
    for(int i=0;i<MAX_THREAD;i++)
    {
      pthread_create(&thread[i],NULL,bucketSort,&tid[i]);
    }
    for (int i = 0; i <MAX_THREAD; i++)
    {
      pthread_join(thread[i],NULL);
    } 

     
      cout << "Sorted array is " <<endl; 
    for (int i=0; i<t; i++) 
       cout << arr[i] << " ";
    cout << endl;    
    return 0; 
} 