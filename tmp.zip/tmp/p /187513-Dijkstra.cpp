#include<stdio.h>
#include<pthread.h>
#include<cstdlib>
#include<algorithm>
#define NODES 4
#define THREADS 2
#define INT_MAX 1000000

int graph[NODES][NODES];
bool sspSet[NODES];
int distance[NODES];
int global_min;
int global_min_index;
int updateNode;
int sum=0;

pthread_mutex_t mut;

void* minDist(void* arg)
{
	int min = INT_MAX,min_index;
	int tid = *(int*)arg;
	int slice = NODES/THREADS;
	for (int v = tid*slice; v < (tid+1)*slice; v++)
    	if (sspSet[v] == false && distance[v] <= min)
    	{
        	min = distance[v];
        	 min_index = v;
    	}

    pthread_mutex_lock(&mut);
    if(min < global_min){
    	global_min_index = min_index;
    	global_min = min;
    }

	pthread_mutex_unlock(&mut);

}

void* updateDist(void* arg)
{
	int tid = *(int*)arg;
	int u = updateNode;
	int slice = NODES/THREADS;
	for (int v = tid*slice; v < (tid+1)*slice; v++)
    	if (!sspSet[v] && graph[u][v] && distance[u] != INT_MAX
									&& distance[u]+graph[u][v] < distance[v])
			distance[v] = distance[u] + graph[u][v];
}

void dijkstra()
{

    for (int i = 0; i < NODES; i++)
    {
    	distance[i] = INT_MAX;
    	sspSet[i] = false;
    }


	distance[0] = 0;

	pthread_t threads[THREADS];
	int Thread_id[THREADS];

	//Initialing thread ID
	for(int i=0; i<THREADS; i++)
	{
		Thread_id[i] = i;
	}

    for (int count = 0; count < NODES; count++)
    {


		global_min = INT_MAX;
    	//Finding Min dist
    	for(int i=0 ; i<THREADS; i++)
		{
			pthread_create(&threads[i],NULL,minDist,&Thread_id[i]);
		}

		for(int i=0 ; i<THREADS; i++)
		{
			pthread_join(threads[i],NULL);
		}

        int u = global_min_index;

        sspSet[u] = true;

        //Update dists
        updateNode = u;
        for(int i=0 ; i<THREADS; i++)
		{
			pthread_create(&threads[i],NULL,updateDist,&Thread_id[i]);
		}

		for(int i=0 ; i<THREADS; i++)
		{
			pthread_join(threads[i],NULL);
		}
    }

}

int main()
{

	//Initialization
	for(int i=0; i<NODES; i++)
	{
		for(int j=0; j<NODES; j++)
		{
			if(i==j)
				graph[i][j] = 0;

			else if(i < j)
			{
				int temp = rand()%100;
				graph[i][j] = temp;
				graph[j][i] = temp;
			}


			printf("%d ",graph[i][j]);
		}

		printf("\n");
	}

	pthread_mutex_init(&mut,NULL);

	dijkstra();

	for (int i = 0; i < NODES; i++)
	    printf("%d to %d\n", i, distance[i]);

}
