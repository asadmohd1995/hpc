#include<stdio.h>
#include<pthread.h>
#include<cstdlib>

#define NODES 4
#define THREADS 2
#define INT_MAX 1000000

int graph[NODES][NODES];
bool mstSet[NODES];
int key[NODES];
int global_min;
int global_min_index;
int updateNode;
int sum=0;

pthread_mutex_t mut;

void* minKey(void* arg)
{	
	int min = INT_MAX,min_index;
	int tid = *(int*)arg;
	int chunk = NODES/THREADS;
	for (int v = tid*chunk; v < (tid+1)*chunk; v++) 
    	if (mstSet[v] == false && key[v] < min) 
    	{
        	min = key[v];
        	 min_index = v;
    	}

    pthread_mutex_lock(&mut);
    if(min < global_min){
    	global_min_index = min_index;
    	global_min = min;
    }

	pthread_mutex_unlock(&mut);

}

void* updateKey(void* arg)
{
	int tid = *(int*)arg;
	int u = updateNode;
	int chunk = NODES/THREADS;
	for (int v = tid*chunk; v < (tid+1)*chunk; v++) 
    	if (graph[u][v] && mstSet[v] == false && graph[u][v] < key[v]) 
            	key[v] = graph[u][v]; 
}
 
void primMST() 
{ 
    
    for (int i = 0; i < NODES; i++)
    {
    	key[i] = INT_MAX;
    	mstSet[i] = false; 
    } 
       
  	
	key[0] = 0;  

	pthread_t threads[THREADS];
	int tid[THREADS];
		
	//Initialing thread ID
	for(int i=0; i<THREADS; i++)
	{
		tid[i] = i;
	}    
 
    for (int count = 0; count < NODES; count++) 
    { 
    	

		global_min = INT_MAX;
    	//Finding Min Key
    	for(int i=0 ; i<THREADS; i++)
		{
			pthread_create(&threads[i],NULL,minKey,&tid[i]);
		}

		for(int i=0 ; i<THREADS; i++)
		{
			pthread_join(threads[i],NULL);
		}
        
        int u = global_min_index; 
  		sum += global_min;
  		printf("%d ",u);
         
        mstSet[u] = true; 
  
        //Update Keys
        updateNode = u; 
        for(int i=0 ; i<THREADS; i++)
		{
			pthread_create(&threads[i],NULL,updateKey,&tid[i]);
		}

		for(int i=0 ; i<THREADS; i++)
		{
			pthread_join(threads[i],NULL);
		} 
    } 
  
} 

int main()
{

	//Initialization
	for(int i=0; i<NODES; i++)
	{
		for(int j=0; j<NODES; j++)
		{
			if(i==j)
				graph[i][j] = 0;

			else if(i < j)
			{
				int temp = rand()%100;
				graph[i][j] = temp;
				graph[j][i] = temp;
			}


			printf("%d ",graph[i][j]);
		}

		printf("\n");
	}

	pthread_mutex_init(&mut,NULL);

	primMST();
	printf("MST-%d\n",sum);
}