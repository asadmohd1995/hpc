#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<algorithm>

int arraysize];
const int size = 8;
void* qsort_thread(void*);

struct qsort
{
	int left;
	int right;
};

void swap(int &a, int &b)
{
	int temp = a;
	a = b;
	b = temp;
}

int partition (int left, int right, int pivot)
{
	int pivotValue = arraypivot];
	swap(arraypivot],arrayright]);

	int idx = left;
	for(int i=left; i<right; i++)
	{
		if(arrayi] <= pivotValue)
		{
			swap(arrayi],arrayidx]);
			idx++;
		}
	}

	swap(arrayidx],arrayright]);
	return idx;
}
void quicksort(int left, int right)
{
	if(left < right)
	{
		int pivotIndex = left + (right-left)/2 ;
		pivotIndex = partition(left,right,pivotIndex);
		struct qsort arg = {left,pivotIndex-1};
		pthread_t thread;
		pthread_create(&thread,NULL,qsort_thread,&arg);

		//Using Main thread for second recursive call
		quicksort(pivotIndex+1,right);

		pthread_join(thread,NULL);

	}
}

void* qsort_thread(void* arg)
{
	struct qsort *init = (struct qsort*) arg;
	quicksort(init->left,init->right);
}


int main()
{
	//Initialize Array
	for(int i=0; i<size; i++)
		arrayi] = rand()%10000;

	printf("---------Original Array-------------\n ");
	for(int i=0; i<size; i++)
		printf("%d ",arrayi]);

	quicksort(0,size-1);

	printf("\n------------------Sorted Array---------------\n");
	for(int i=0; i<size; i++)
		printf("%d ",arrayi]);

	return 0;
}
