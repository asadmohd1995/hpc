#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#define MAX_THREAD 16
//pthread_barrier_t barrier;
#define V 5
int reach[V][V];
int graph[V][V];
/*int graph[V][V] = { {1, 1, 0, 1, 1, 0 },
                    {0, 1, 1, 0, 1, 1 },
                    {0, 0, 1, 1, 0, 1 },
                    {0, 1, 0, 1, 1, 0 },
                    {0, 0, 1, 1, 1, 1 },
                    {0, 1, 0, 1, 1, 1 },
                  };
*/
void makegraph(int nodes)
{
  for (int i = 0; i < nodes; i++)
  {
    for (int j = 0; j < nodes; j++)
     {
       if(i==j)
       {
         graph[i][j]=1;
       }
       else
       {
          graph[i][j]=rand()%2;
       }
    }

  }
}



void* transitiveClosure(void *arg)
{

    int  i, j, k;
    for (i = 0; i < V; i++)
        for (j = 0; j < V; j++)
            reach[i][j] = graph[i][j];


    for (k = 0; k < V; k++)
    {
      //  pthread_barrier_wait(&barrier);
        for (i = 0; i < V; i++)
        {

            for (j = 0; j < V; j++)
            {
              reach[i][j] = reach[i][j] || (reach[i][k] && reach[k][j]);
            }
        }
    }


}

void directedgraph()
{
    printf ("Following matrix is the given graph\n");
    for (int i = 0; i < V; i++)
    {
        for (int j = 0; j < V; j++)
            printf ("%d ", graph[i][j]);
        printf("\n");
    }

}

void printSolution(int reach[][V])
{
    printf ("Following matrix is transitive closure of the given graph\n");
    for (int i = 0; i < V; i++)
    {
        for (int j = 0; j < V; j++)
            printf ("%d ", reach[i][j]);
        printf("\n");
    }

}

int main()
{

    pthread_t thread[MAX_THREAD];
    makegraph(V);
    directedgraph();
    //pthread_barrier_init(&barrier,NULL,MAX_THREAD);
    for(int i=0;i<MAX_THREAD;i++)
    {
      pthread_create(&thread[i],NULL,transitiveClosure,NULL);
    }

    for (int i = 0; i < MAX_THREAD; i++)
    {
      pthread_join(thread[i],NULL);
    }
    printSolution(reach);
    return 0;
}
