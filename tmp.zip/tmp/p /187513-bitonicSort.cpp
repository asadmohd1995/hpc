#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

#define SIZE 8

void* bsort_thread(void*);
void* bsort_merge(void*);

int arr[SIZE];

struct bsort
{
	int low;
	int cnt;
	int dir;
};

void swap(int &a, int &b)
{
	int temp = a;
	a = b;
	b = temp;
}

void compAndSwap(int i, int j, int dir)
{
    if (dir==(arr[i]>arr[j]))
        swap(arr[i],arr[j]);
}

void bitonicMerge(int low, int cnt, int dir)
{
    if (cnt>1)
    {
        int k = cnt/2;
        for (int i=low; i<low+k; i++)
            compAndSwap(i, i+k, dir);

        struct bsort arg = {low,k,dir};
		pthread_t thread;
		pthread_create(&thread,NULL,bsort_merge,&arg);

        bitonicMerge(low+k, k, dir);
        pthread_join(thread,NULL);
    }
}

void bitonicSort(int low, int cnt, int dir)
{
    if (cnt>1)
    {
        int k = cnt/2;
        struct bsort arg = {low,k,1};
		pthread_t thread;
		pthread_create(&thread,NULL,bsort_thread,&arg);

        bitonicSort(low+k, k, 0);

  		pthread_join(thread,NULL);
        //sorting
        bitonicMerge(low, cnt, dir);
    }
}

void* bsort_thread(void* arg)
{
	struct bsort *init = (struct bsort*) arg;
	bitonicSort(init->low, init->cnt, init->dir);
}

void* bsort_merge(void* arg)
{
	struct bsort *init = (struct bsort*) arg;
	bitonicMerge(init->low, init->cnt, init->dir);
}
// Driver code
int main()
{
    for(int i=0; i<SIZE; i++)
		arr[i] = rand()%100;

    //dir = 1 Ascending
    //dir = 0 descending
    bitonicSort(0, SIZE, 1);

    printf("Sorted array: \n");
    for (int i=0; i<SIZE; i++)
        printf("%d ", arr[i]);
    return 0;
}
