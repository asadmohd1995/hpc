#include <stdio.h>
#include <pthread.h>
#define N 3
#define M 1
int a[N][N];
int b[N][M];
int c[N][M];

void *mult(void *k)
{
   int*j=(int *)k;
   int i=*j;
   int n,m;
   int sum=0;
   //multiply matrix
  for(m=0;m<M;m++)
  {
   for(n=0;n<N;n++)
   {
     sum+=a[i][n]*b[n][m];
   }
   c[i][m]=sum;
   sum=0;
 }
}


int main()
{   
	int i,j,k,l;
	printf("enter array elements of a\n");
    for(j=0;j<N;j++)
	{
		for(k=0;k<N;k++)
		{
			scanf("%d",&a[j][k]);
		}
	}

	printf("enter array elements of b\n");
    for(j=0;j<N;j++)
	{
		for(k=0;k<M;k++)
		{
			scanf("%d",&b[j][k]);
		}
	}

	pthread_t t[N];
	for(i=0;i<N;i++)
	{
      pthread_create(&t[i],NULL,mult,&i);
     
      pthread_join(t[i],NULL);
     
	}
	printf("array c is\n");
	for(j=0;j<N;j++)
	{
		for(k=0;k<M;k++)
		{
			printf("%d  ",c[j][k]);
			
		}
		printf("\n");
	}

	return 0;
}

