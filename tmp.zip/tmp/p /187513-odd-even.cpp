#include<stdio.h>
#include<cstdlib>
#include<pthread.h>
#include<bits/stdc++.h>

#define SIZE 1000
#define THREADS 100
int array[SIZE];
pthread_barrier_t barrier;

void init()
{
	for(int i=0; i<SIZE; i++)
	{
		array[i] = rand()%1000;
	}
}

void swap(int a,int b)
{
	int temp = array[a];
	array[a] = array[b];
	array[b] = temp;
}

void* odd_even(void* arg)
{
	int id = *((int*)arg);


	for(int i=1; i<=SIZE; i++)
	{
		pthread_barrier_wait(&barrier);

		if(i % 2 != 0)
		{
			if(id%2==0)
			{
				if(array[id]>array[id+1])
					swap(id,id+1);
			}
		}

		else
		{
			if(id%2 != 0)
			{
				if(array[id]>array[id+1])
					swap(id,id+1);
			}
		}
	}
}

int main()
{
	//Initialize Array
	init();

	pthread_t threads[THREADS];
	pthread_barrier_init(&barrier, NULL, THREADS);
	int tid[THREADS];
	//Initialing thread ID
	for(int i=0; i<THREADS; i++)
	{
		tid[i] = i;
	}

	printf("----------------Origianl Array-------------------------------\n");
	for(int i=0 ; i<SIZE; i++)
	{
		printf("%d ",array[i]);
	}
	printf("\n");

	//Creating Threads
	for(int i=0 ; i<THREADS; i++)
	{
		pthread_create(&threads[i],NULL,odd_even,&tid[i]);
	}

	for(int i=0 ; i<THREADS; i++)
	{
		pthread_join(threads[i],NULL);
	}

	printf("----------------Sort Array-------------------------------\n");
	for(int i=0 ; i<SIZE; i++)
	{
		printf("%d ",array[i]);
	}
	printf("\n");
}
